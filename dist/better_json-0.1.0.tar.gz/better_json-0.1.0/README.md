# JSON Wrapper

Adds 2x much needed wrapper functions to the JSON library.

1. read_json
2. write_json
